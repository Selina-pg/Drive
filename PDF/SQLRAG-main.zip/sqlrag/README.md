
# UniSQL

UniSQL 結合 VannaAI 和 Milvus 向量資料庫，並串接 SQL Server 資料庫，透過自然語言查詢資料、自動生成 SQL 並以圖表方式呈現結果，適合需要快速資料探索和分析的應用場景。

---

## Docker 快速部署

- **容器名稱**：`UniSQL`
- **服務位置**：`10.13.18.40:21003`

### 部署或更新方式

1. 程式修改完成後，於專案目錄下執行：
    ```bash
    docker-compose down --rmi all
    docker-compose up
    ```
2. 應用程式會重新啟動並載入最新程式碼。

---

## 系統簡介

### 串接關聯式資料庫
- 目前串接兩個 SQL Server 資料庫：YM_ALMS（生成式 AI 使用紀錄）和 MES 系統資料庫（MES 過帳紀錄）。
- 在前端常數 `DATABASES` 中新增欲查詢的資料庫，並在 `vanna_calls` 和 `db_connection.py` 中新增資料庫及 Milvus 連線資訊，即可串接新的 SQL Server 資料庫。

### 如何新增資料庫
1. 在 `app.py` 中新增 `DATABASES` 常數。
2. `vanna_calls.py` 中的 `get_current_database()` 會從 Streamlit 前端獲取目前所選的資料庫。
3. `get_vanna_instance()` 繼承 `setup_vanna()`，並額外傳入 `database` 參數。
4. `setup_vanna()` 是 Myvanna 的實例化程式，Myvanna 會呼叫 `db_connection.py` 的 `create_connection()` 獲取資料庫連線資訊。
5. 在 `db_connection.py` 的 `DB_CONFIGS` 中新增對外顯示的資料庫名稱及 SQL Server 連線資訊（Server, ID, Password 等等）。

### 新增的資料庫串接 VectorDB
1. 新增 SQL 資料庫連線後，需新增新的 VectorDB 來儲存新串的 Table Schema。首先進入 Milvus UI 新增 Database 名稱，取名為：`SQLRAG_XXX`。
2. 在 `vanna_calls.py` 中新增 `MILVUS_CONFIGS`，新增對外顯示的資料庫名稱及對應的參數，`actual_db` 為剛剛設定的 `XXX`。
3. Milvus 串接好後，Vanna 會自動新增三個 collections（`ddl`, `docs`, `question-sql`）。


### 將 Table Schema 加入 Milvus 讓 LLM 知道資料庫中的 Table Schema

1. 透過 `tool/auto_add_ddl.ipynb` 自動將串接的資料庫的 Table Schema 加入 Milvus DB（需修改 `auto_add_ddl` 連線資訊等參數）。
2. `auto_add_ddl.ipynb` 還會讓 LLM 看過 Table Schema 後自動產生 document（第二個 collection），可以進 Milvus UI 確認效果，不喜歡或非必要可直接刪除。
3. 若不想透過 `auto_add_ddl.ipynb`，可自己寫一隻程式，設定好連線資訊後，透過 `setup_vanna()` 實例化，再用 `train()` 方法來新增 ddl 等 vector 資料。
   - 例如：`vn.train(ddl=ddl)` 加入 ddl, `vn.train(document=document)` 加入文檔, `vn.train(question=question, sql=sql)` 加入問題-sql。
   - 可以參考 `tool/dbtest.ipynb` 的程式。


### 自然語言查詢（SQL-RAG）
- 透過 VannaAI，LLM 會根據資料庫表格欄位自動產生合適的 SQL 查詢語法。
- 生成方式請參照 `/vanna/base/base.py`。

### 查詢結果顯示
- 在 SQL Server 執行 SQL，將結果存在表格（DataFrame），並顯示在介面上。

### 資料視覺化
- LLM 自動生成 Python Plotly 程式碼，將結果繪製成圖表。
- 主要透過 `/vanna/base/base.py` 的 `generate_plotly_code()` 實現，並從 `vanna_calls.py` 呼叫，可自行修改 Prompt。

---

## 主要程式檔案

- `app.py`：Streamlit 主程式
- `utils.py`：輔助功能
- `valid.py`：驗證邏輯
- `vanna_calls.py`：VannaAI 呼叫與後端邏輯（會呼叫 `base.py` 執行 SQL-RAG 操作），Milvus 連線
- `/vanna/base/base.py`：VannaAI 主要程式，生成 SQL、生成圖表、system message、initial prompt 等等的 Prompt 都在這裡修改
- `db_connection.py`：資料庫串接

---

## Milvus 向量庫資訊

- **Collections**：`SQLRAG_資料庫名稱`（例如：SQLRAG_YM_ALMS）
  - 主 collection：`vannaddl`
  - 其他：`vannadoc`, `vannasql`
- **Milvus UI**：`10.13.18.40:8000`
- **Milvus Address**：`10.13.18.40:19530`

---



---
> 目前功能仍在開發中。
> User窗口: 無對接User
streamlit run app.py

