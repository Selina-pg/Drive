import time
import streamlit as st
from vanna_calls import (
    generate_questions_cached,
    generate_sql_cached,
    run_sql_cached,
    is_sql_valid_cached,
    generate_summary_cached,
    train_model_cached,
    should_generate_chart_cached,
    generate_plotly_code_cached,
    generate_plot_cached
)
from valid import generate_relevance_check
# Import functions from utils.py
from utils import (
    AVATAR_URL,
    MAX_CONTEXT_TURNS,
    MAX_SQL_GENERATION_ATTEMPTS,
    init_session_state,
    reset_training_state,
    reset_chat,
    add_to_chat_history,
    update_context,
    display_message,
    generate_and_validate_sql,
    process_and_display_results,
    handle_yes_click,
    handle_no_click,
    process_think_tags,
    clear_cache_on_db_change,
    classify_sql_difficulty
)

# 常數定義
DATABASES = ["生成式AI應用使用紀錄","MES過帳紀錄"]

# Chat History Display
def display_chat_history():
    """Display chat history"""
    for message in st.session_state.chat_history:
        with st.chat_message(message["role"], 
                           avatar=AVATAR_URL if message["role"] == "assistant" else None):
            
            if message["role"] == "assistant":
                # Process any <think> tags in the content
                content, think_matches = process_think_tags(message["content"])
                st.write(content)
                
                # If there are think tags, display their content in an expander
                if think_matches:
                    with st.expander("LLM Reasoning Process", expanded=False):
                        for i, think_content in enumerate(think_matches):
                            if i > 0:  # Add separator if multiple think blocks
                                st.markdown("---")
                            st.markdown(think_content)
            else:
                # If it's a user message, just display it normally
                st.write(message["content"])
            
            # Display additional content (SQL, data, charts)
            if "sql" in message and st.session_state.get("show_sql", True):
                st.code(message["sql"], language="sql", line_numbers=True)
            if "data" in message and st.session_state.get("show_table", True):
                if len(message["data"]) > 30:
                    st.text("顯示出資料庫查詢前30筆資料")
                    st.dataframe(message["data"].head(30))
                else:
                    st.dataframe(message["data"])
            if "chart" in message and message["chart"] is not None and st.session_state.get("show_chart", True):
                st.plotly_chart(message["chart"], use_container_width=True)

def display_data_frame(df):
    """Display data frame"""
    if len(df) > 30:
        st.text("顯示出資料庫查詢前10筆資料")
        st.dataframe(df.head(30))
    else:
        st.dataframe(df)

# UI Related Functions
def setup_sidebar():
    """Setup sidebar"""
    # Add logo and brand identity
    st.sidebar.markdown("""
    <div style='text-align: center; margin-bottom: 20px;'>
        <h2 style='color: #1E88E5;'>UniSQL</h2>
        <p style='color: #666; font-size: 0.9em;'>智慧資料分析平台</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Display current user and time
    st.sidebar.markdown(f"""
    <div style='text-align: center; margin-bottom: 15px; background-color: #f0f2f6; padding: 10px; border-radius: 5px;'>
        <p style='margin: 0; font-size: 0.8em;'>
        </p>
    </div>
    <hr>
    """, unsafe_allow_html=True)
    
    # Store the previous database selection if it exists
    if 'database_selector' in st.session_state and not hasattr(st.session_state, 'previous_db'):
        st.session_state.previous_db = st.session_state.database_selector
    
    # Database selection area
    st.sidebar.markdown("### 資料庫選擇")
    current_db = st.sidebar.selectbox(
        "選擇要查詢的資料庫",
        options=DATABASES,
        key="database_selector",
        help="切換不同資料庫進行查詢"
    )
    
    # Clear cache if database changed
    clear_cache_on_db_change()
    
    # Display options area
    st.sidebar.markdown("### 🛠️ 顯示設定")
    st.sidebar.checkbox("顯示SQL指令", value=True, key="show_sql", help="顯示生成的SQL查詢語句")
    st.sidebar.checkbox("顯示資料表", value=True, key="show_table", help="顯示查詢結果資料表")
    show_chart = st.sidebar.checkbox("產生圖表", value=True, key="show_chart", help="根據結果生成視覺化圖表")
    
    # Advanced options area
    with st.sidebar.expander("⚙️ 進階選項", expanded=False):
        display_limit = st.number_input(
            "顯示筆數",
            min_value=10,
            max_value=100,
            value=30,
            step=10,
            key="display_limit",
            help="控制頁面上即時顯示的資料筆數"
        )
        query_limit = st.number_input(
            "查詢筆數上限",
            min_value=50,
            max_value=1000,
            value=200,
            step=50,
            key="max_results",
            help="限制SQL查詢返回的最大結果筆數"
        )
        
        if show_chart:
            st.selectbox(
                "預設圖表類型",
                ["自動選擇", "長條圖", "折線圖", "圓餅圖", "散點圖"],
                key="default_chart_type",
                help="選擇預設的視覺化圖表類型"
            )
    
    # Add operation buttons area
    st.sidebar.button(
    "重置對話",
    on_click=reset_chat,
    use_container_width=True,
    help="清除所有聊天歷史記錄並重新開始"
    )
    
    # Add explanation information
    st.sidebar.markdown("---")
    st.sidebar.markdown(f"""
    <div style='text-align: center; color: #666; font-size: 0.8em;'>
        <p>UniSQL 智慧資料分析助手 v1.0.0</p>
        <p>有任何問題請聯絡U00972@gmail.com</p>
    </div>
    """, unsafe_allow_html=True)
    
    return current_db

def display_welcome_message(current_db):
    """Display welcome message"""
    assistant_message = st.chat_message("assistant", avatar=AVATAR_URL)
    assistant_message.write("你好！我是SQL專家，有任何有關SQL指令的問題可以問我唷！")
    assistant_message.write(f"您目前選擇的資料庫是: {current_db}")

def display_db_switch_message(current_db):
    """Display database switch message"""
    if st.session_state.previous_db and st.session_state.previous_db != current_db:
        switch_message = st.chat_message("assistant", avatar=AVATAR_URL)
        switch_message.write(f"切換資料庫到: {current_db}")

def validate_and_train(validation_message, question, sql):
    """Process validation and training flow"""
    col1, col2 = validation_message.columns(2)
    
    # Use on_click to handle button click events
    col1.button("👍", 
                key=f"yes_button_{hash(question)}", 
                on_click=handle_yes_click)
    
    col2.button("👎", 
                key=f"no_button_{hash(question)}", 
                on_click=handle_no_click)
    
    return st.session_state.training_state.get('trained', False)

def process_question(question):
    """Main function for processing user questions without pagination"""
    # 1. Immediately display user message
    with st.chat_message("user"):
        st.write(question)
    
    # Add user message to history
    add_to_chat_history("user", question)
    
    # 2. Generate SQL and display
    with st.chat_message("assistant", avatar=AVATAR_URL):
        with st.spinner("DeepSeek正在思考..."):
            sql = None
            attempts = 0
            while attempts < MAX_SQL_GENERATION_ATTEMPTS:
                difficulty = classify_sql_difficulty(question = question)
                sql = generate_sql_cached(question=question, difficulty = difficulty)
                if not sql:
                    st.write("無法生成SQL查詢，請重新描述您的問題。")
                    return
                    
                if is_sql_valid_cached(sql=sql):
                    break
                    
                attempts += 1
                generate_sql_cached.clear()
                
                if attempts == MAX_SQL_GENERATION_ATTEMPTS:
                    st.write("無法生成有效的SQL查詢，請重新描述您的問題。")
                    return
        
        # Display SQL
        if st.session_state.get("show_sql", True):
            st.code(sql, language="sql", line_numbers=True)

        # 3. Execute query and display results
        with st.spinner("執行查詢中..."):
            # Execute SQL query
            df = run_sql_cached(sql=sql)
            
            if df is None:
                st.error("執行SQL查詢時發生錯誤或沒有結果。")
                return
                
            if st.session_state.get("show_table", True):
                # Get user-specified max result count
                max_results = st.session_state.get("max_results", 100)
                
                # Apply result limit
                if len(df) > max_results:
                    df = df.head(max_results)
                
                # 為每個查詢創建唯一標識符
                query_id = hash(question + sql)
                
                # 初始化關鍵session state變量
                summary_key = f"summary_{query_id}"
                think_key = f"think_{query_id}"
                first_load_key = f"first_load_{query_id}"
                
                # 處理首次載入
                if first_load_key not in st.session_state:
                    st.session_state[first_load_key] = True
                else:
                    st.session_state[first_load_key] = False
                
                # 處理摘要和思考過程
                if summary_key not in st.session_state or st.session_state[first_load_key]:
                    # 首次載入或強制重新生成摘要
                    with st.spinner("生成摘要..."):
                        if len(df) > 300:
                            df_limited = df.head(300)
                            raw_summary = generate_summary_cached(question, df_limited)
                        else:   
                            raw_summary = generate_summary_cached(question, df)
                        processed_summary, think_matches = process_think_tags(raw_summary)
                        
                        # 存儲處理後的摘要和思考過程
                        st.session_state[summary_key] = processed_summary
                        st.session_state[think_key] = think_matches

                else:
                    # 使用已存儲的摘要和思考過程
                    processed_summary = st.session_state[summary_key]
                    think_matches = st.session_state[think_key]
                
                # 顯示摘要
                st.write(processed_summary)
                
                # 顯示LLM思考過程
                if think_matches:
                    with st.expander("LLM Reasoning Process", expanded=False):
                        for i, think_content in enumerate(think_matches):
                            if i > 0:  # 添加分隔線
                                st.markdown("---")
                            st.markdown(think_content)
                
                # 顯示資料資訊
                result_info = f"（共 {len(df)} 筆資料"
                if len(df) > max_results:
                    result_info += f"，限制 {max_results} 筆"
                result_info += "）"
                
                st.text(f"顯示所有資料 {result_info}")
                st.dataframe(df)  # 直接顯示完整的數據框
                
                # 4. Generate chart (if needed)
                chart_content = None
                fig = None
                if st.session_state.get("show_chart", True):
                    with st.spinner("生成圖表中..."):
                        if should_generate_chart_cached(df=df):
                            # Get user-selected chart type
                            chart_type = st.session_state.get("default_chart_type", "自動選擇")
                            
                            # Modify question content based on chart type
                            augmented_question = question
                            if chart_type != "自動選擇":
                                chart_type_mapping = {
                                    "長條圖": "bar chart",
                                    "折線圖": "line chart",
                                    "圓餅圖": "pie chart",
                                    "散點圖": "scatter plot"
                                }
                                english_chart_type = chart_type_mapping.get(chart_type, "appropriate chart")
                                augmented_question = f"{question} Please use a {english_chart_type} to visualize the results."
                            
                            # Generate chart code using modified question
                            code = generate_plotly_code_cached(question=augmented_question, sql=sql, df=df)
                            
                            if code is not None and code != "":
                                try:
                                    fig = generate_plot_cached(code=code, df=df)
                                    if fig is not None:
                                        st.write("\n以下是根據查詢結果生成的圖表分析：")
                                        st.plotly_chart(fig, use_container_width=True)
                                        chart_content = "以下是根據查詢結果生成的圖表分析"
                                except Exception as e:
                                    st.error(f"生成圖表時發生錯誤：{str(e)}")
                
                # Add all results to a single history record
                final_content = processed_summary
                if chart_content:
                    final_content = f"{processed_summary}\n\n{chart_content}"
                
                # 只在首次載入時添加到聊天歷史
                if st.session_state[first_load_key]:
                    # Only add history record once, including all content
                    message = add_to_chat_history(
                        "assistant",
                        final_content,
                        sql=sql,
                        data=df,
                        chart=fig if fig is not None else None
                    )
                    
                    # 5. Display evaluation block and correctly connect validate_and_train function
                    st.write("\n這個回答是否有幫助？")
                    # Create container for evaluation buttons
                    validation_container = st.container()
                    
                    # Update training state
                    st.session_state.training_state['current_question'] = question
                    st.session_state.training_state['current_sql'] = sql
                    
                    # Pass container to validate_and_train function
                    validate_and_train(validation_container, question, sql)

def show_introduction():
    """Display application features introduction"""
    with st.expander("🔍 了解 UniSQL 智慧資料分析助手", expanded=False):
        st.markdown("""
        ## 🌟 主要功能
        
        ### 自然語言轉 SQL
        - 直接用日常語言提問，無需編寫複雜的 SQL 語句
        - 系統自動生成精確的 SQL 查詢並執行
        
        ### 資料分析
        - 自動生成數據摘要，幫助快速理解查詢結果
        - 提供關鍵見解和數據趨勢說明
        
        ### 視覺化圖表
        - 根據數據特性自動選擇合適的圖表類型
        - 支持自定義圖表風格和類型
        
        ### 持續學習優化
        - 通過反饋不斷改進查詢準確性
        - 記住常用問題模式，提高回答效率
        
        ## 💡 使用技巧
        
        1. **清晰描述需求** - 例如「顯示2025年第一季度銷售額前五名的產品及其銷售數量」
        2. **指定時間範圍** - 「最近30天」、「上個月」、「今年第一季度」等
        3. **表達排序需求** - 「按銷售額排序」、「從高到低排列」等
        4. **限制結果數量** - 「前10名」、「最高的5個」等
        
        """)
        
        st.markdown("<small>點擊此框外任意位置關閉介紹 ↗</small>", unsafe_allow_html=True)
        
        # Use ordinary variable instead of session_state to control button operation
        hide_intro = False
        if st.button("不再顯示此介紹", key="close_intro"):
            st.session_state.show_intro = False
            st.success("已設定下次不再顯示介紹！")

def main():
    """Main function"""
    # Page configuration - use widescreen layout and set title icon
    st.set_page_config(
        page_title="UniSQL Assistant",
        page_icon="🔍",
        initial_sidebar_state="expanded"
    )
    
    init_session_state()
    
    # Application title and introduction area
    col1, col2 = st.columns([5, 1])
    
    with col1:
        st.markdown("""
        #  UniSQL 智慧資料分析
        <p style='font-size: 0.9em; color: #555; margin-top: -10px;'>將複雜的數據查詢轉換為簡單對話，讓資料分析更輕鬆</p>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div style='text-align: right; color: #666; font-size: 0.8em; padding-top: 10px;'>
        </div>
        """, unsafe_allow_html=True)
    
    # Divider
    st.markdown("<hr style='margin-top: 0; margin-bottom: 20px;'>", unsafe_allow_html=True)
    
    # Show features introduction on first visit
    if st.session_state.show_intro and not st.session_state.chat_history:
        show_introduction()
    
    # Sidebar setup
    current_db = setup_sidebar()
    
    # Main content area - use container to organize interface
    chat_container = st.container()
    
    with chat_container:
        # Display chat history
        display_chat_history()
        
        # If no chat history, display welcome message
        if not st.session_state.chat_history:
            with st.chat_message("assistant", avatar=AVATAR_URL):
                st.markdown(f"""
                歡迎使用 UniSQL !
                我可以幫助您：
                - 將自然語言轉換為 SQL 查詢
                - 生成可視化圖表查詢結果
                - 提供見解和摘要說明
                
                您目前選擇的資料庫是: **{current_db}**
                """)
    
    # Check if there's a selected question
    selected_question = st.session_state.get('selected_question', None)
    if selected_question:
        # Clear selection to avoid repeated processing
        st.session_state.selected_question = None
        # Process the selected question
        process_question(selected_question)
    
    # User input box - add prompt text and icon
    user_input = st.chat_input("開始和您的資料庫進行對話")
    if user_input:
        relevance_result = generate_relevance_check(user_input)
        if relevance_result == "NO":
            error_msg = "您的問題似乎與資料庫無關，請嘗試詢問資料庫查詢相關的問題。"
            error_message = add_to_chat_history("assistant", error_msg)
            display_message(error_message)
            return None
        else:
            process_question(user_input)

if __name__ == "__main__":
    main()
    #streamlit run app.py


