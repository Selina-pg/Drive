import time
import re
import requests
import json
from urllib.parse import urlencode
import streamlit as st
from vanna_calls import (
    generate_questions_cached,
    generate_sql_cached,
    run_sql_cached,
    is_sql_valid_cached,
    generate_summary_cached,
    train_model_cached,
    should_generate_chart_cached,
    generate_plotly_code_cached,
    generate_plot_cached
)
from valid import (
    call_llm_for_relevance,
    generate_relevance_check
)

# Constants
AVATAR_URL = "img/image.png"
MAX_CONTEXT_TURNS = 10
MAX_SQL_GENERATION_ATTEMPTS = 5

# Session State Initialization
def init_session_state():
    """Initialize all session states"""
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "previous_db" not in st.session_state:
        st.session_state.previous_db = None
    if "context" not in st.session_state:
        st.session_state.context = []
    if "training_state" not in st.session_state:
        st.session_state.training_state = {
            'validated': False,
            'trained': False,
            'current_question': None,
            'current_sql': None
        }
    if "show_intro" not in st.session_state:
        st.session_state.show_intro = True

def reset_training_state(question):
    """Reset training state"""
    st.session_state.training_state = {
        'validated': False,
        'trained': False,
        'current_question': question,
        'current_sql': None
    }

# Chat History Related Functions
def reset_chat():
    """Reset all chat-related states"""
    st.session_state.chat_history = []
    st.session_state.context = []
    st.session_state.training_state = {
        'validated': False,
        'trained': False,
        'current_question': None,
        'current_sql': None
    }

def add_to_chat_history(role, content, sql=None, data=None, chart=None):
    """Add message to chat history"""
    message = {
        "role": role,
        "content": content,
        "timestamp": time.time()
    }
    if sql:
        message["sql"] = sql
    if data is not None:
        message["data"] = data
    if chart is not None:
        message["chart"] = chart
    st.session_state.chat_history.append(message)
    
    # Update context
    update_context(role, content, sql)
    
    # Return message for immediate display
    return message

def update_context(role, content, sql=None):
    """Update conversation context"""
    if role == "user":
        st.session_state.context.append({"role": "user", "content": content})
    elif role == "assistant":
        context_content = content
        if sql:
            context_content += f"\nSQL: {sql}"
        st.session_state.context.append({"role": "assistant", "content": context_content})
    
    # Keep context within defined limit
    if len(st.session_state.context) > MAX_CONTEXT_TURNS * 2:
        st.session_state.context = st.session_state.context[-MAX_CONTEXT_TURNS * 2:]

def process_think_tags(content):
    """處理包含 <think> 標籤的內容並放入摺疊區域
    
    Returns:
        tuple: (已處理的內容, 思考內容列表)
    """
    # 檢查內容是否為 None
    if content is None:
        return "", []
    
    # 使用非貪婪模式匹配，確保正確捕獲多個 <think> 區塊
    pattern = r'<think>(.*?)</think>'
    matches = re.findall(pattern, content, re.DOTALL)
    
    if not matches:
        return content, []
    
    # 從內容中移除 <think> 標籤及其內容
    processed_content = re.sub(pattern, '', content, flags=re.DOTALL)
    processed_content = processed_content.strip()
    
    return processed_content, matches

def display_message(message):
    """Display a single message in real-time"""
    with st.chat_message(message["role"], avatar=AVATAR_URL if message["role"] == "assistant" else None):
        content = message["content"]
        processed_content, think_matches = process_think_tags(content)
        
        # Display the main content
        st.write(processed_content)
        
        # If there are think tags, display their content in an expander
        if think_matches:
            with st.expander("LLM Reasoning Process", expanded=False):
                for i, think_content in enumerate(think_matches):
                    if i > 0:  # Add separator if multiple think blocks
                        st.markdown("---")
                    st.markdown(think_content)
        
        # Display SQL, data and charts if available
        if "sql" in message:
            st.code(message["sql"], language="sql", line_numbers=True)
        if "data" in message:
            if len(message["data"]) > 30:
                st.text("顯示出資料庫查詢前30筆資料")
                st.dataframe(message["data"].head(30))
            else:
                st.dataframe(message["data"])
        if "chart" in message and message["chart"] is not None:
            st.plotly_chart(message["chart"], use_container_width=True)

# SQL Processing Functions
def generate_and_validate_sql(question):
    """Generate and validate SQL query"""
    attempts = 0
    last_sql = None
    
    while attempts < MAX_SQL_GENERATION_ATTEMPTS:
        # Generate SQL
        sql = generate_sql_cached(question=question)
        last_sql = sql  # Save the last generated SQL
        
        # Check if SQL was generated successfully
        if not sql:
            error_msg = "無法生成SQL查詢，請重新描述您的問題。"
            error_message = add_to_chat_history("assistant", error_msg)
            display_message(error_message)
            return None
            
        # Validate SQL
        if is_sql_valid_cached(sql=sql):
            st.session_state.training_state['current_sql'] = sql
            return sql
            
        # SQL validation failed, increment attempts
        attempts += 1
        generate_sql_cached.clear()
        
        # If max attempts reached
        if attempts == MAX_SQL_GENERATION_ATTEMPTS:
            error_msg = f"成功生成SQL，但無法正確於資料庫中執行，可以檢查看看。\n\n最後嘗試的 SQL 查詢是："
            error_message = add_to_chat_history("assistant", error_msg, sql=last_sql)
            display_message(error_message)
            return None
    
    return None

def process_and_display_results(question, sql):
    """Process and display query results"""
    # Execute SQL query
    df = run_sql_cached(sql=sql)
    
    if df is not None and st.session_state.get("show_table", True):
        # Get user-specified max result count
        max_results = st.session_state.get("max_results", 100)
        
        # Apply result limit
        if len(df) > max_results:
            df = df.head(max_results)
        
        # Only take first 30 rows for processing
        df_limited = df.head(30)
        
        # Generate summary using limited data
        summary = generate_summary_cached(question, df_limited)
        
        # Add all content to one message
        message_content = [
            summary,
            f"\n\n以下是SQL查詢結果（限制顯示 {max_results} 筆）："
        ]
        
        # Create complete message and display immediately
        message = add_to_chat_history(
            "assistant",
            "\n".join(message_content),
            sql=sql,
            data=df_limited
        )
        display_message(message)
        
        # Auto-train model
        try:
            train_model_cached(question=question, sql=sql)
        except Exception as e:
            print(f"Model training error: {str(e)}")
        
        return df_limited
    return None

# Validation and Training Functions
def handle_yes_click():
    """Handle 'yes' button click event"""
    if 'current_question' in st.session_state.training_state and 'current_sql' in st.session_state.training_state:
        question = st.session_state.training_state['current_question']
        sql = st.session_state.training_state['current_sql']
        with st.spinner("模型訓練中..."):
            success = train_model_cached(question=question, sql=sql)
            if success:
                success_msg = "訓練完成，您可以繼續提問！"
                success_message = add_to_chat_history("assistant", success_msg)
                st.session_state.training_state['trained'] = True

def handle_no_click():
    """Handle 'no' button click event"""
    error_msg = "謝謝您的回饋，我們會繼續改進。"
    error_message = add_to_chat_history("assistant", error_msg)
    display_message(error_message)
    
def clear_cache_on_db_change():
    """Clear relevant caches when database is changed"""
    if 'previous_db' in st.session_state and st.session_state.previous_db != st.session_state.database_selector:
        # Clear all cached functions from vanna_calls
        generate_questions_cached.clear()
        generate_sql_cached.clear()
        is_sql_valid_cached.clear()
        run_sql_cached.clear()
        generate_summary_cached.clear()
        train_model_cached.clear()
        should_generate_chart_cached.clear()
        generate_plotly_code_cached.clear()
        generate_plot_cached.clear()
        
    # Always update previous_db
    st.session_state.previous_db = st.session_state.database_selector
    
def get_query_params():
    """獲取URL查詢參數"""
    try:
        # 在Streamlit中獲取URL參數的方法
        return st.experimental_get_query_params()
    except:
        return {}
        
# 創建帶參數的URL
def create_url_with_params(params):
    """創建帶參數的URL"""
    base_url = st.runtime.get_instance().query_string
    base_url = base_url.split('?')[0] if '?' in base_url else base_url
    return f"{base_url}?{urlencode(params)}"

def classify_sql_difficulty(question):
    """
    Classifies SQL queries into three difficulty levels using the deepseek model:
    - EASY: Single table queries without JOIN and NESTING
    - NON-NESTED: Queries requiring JOIN but without NESTING
    - NESTED: Queries containing JOIN, Sub-Query, and Set Operations
    
    Args:
        question (str): The SQL question/query to be classified
        
    Returns:
        str: The difficulty level ("EASY", "NON-NESTED", or "NESTED")
    """
    # Model endpoint
    url = "http://10.13.18.40:55688/v1/chat/completions"
    
    # Prepare the prompt to instruct the model about classification rules in traditional Chinese
    system_msg = "你是一個 SQL 分析助手，負責對 SQL 查詢的難度進行分類。"
    user_msg = f"""
    分析以下 SQL 問題，並將其難度分類為以下其中之一：
    - EASY: 單一表單查詢，沒有 JOIN 和 NESTING。
    - NON-NESTED: 需要參照其他表或是做Join，但不需要 NESTING 的查詢。
    - NESTED: 包含 JOIN、Sub-Query 和 Set Operations。
    
    請只回答這三個難度等級之一：EASY, NON-NESTED, 或 NESTED。
    
    SQL 問題: {question}
    """
    
    messages = [
        {"role": "system", "content": system_msg},
        {"role": "user", "content": user_msg}
    ]
    
    # Prepare the request payload
    data = {
        "model": "DeepSeek-R1-Distill-Qwen-32B",
        "temperature": 0.1,
        "stream": False,
        "messages": messages
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    try:
        # Make the request to the model
        response = requests.post(url, json=data)
        
        # 輸出響應以便調試
        print(f"API Response Status: {response.status_code}")
        response_text = response.text
        print(f"API Response: {response_text[:200]}...")
        
        response_dict = response.json()
        model_response = response_dict["choices"][0]["message"]["content"].strip()
        
        # 保存原始回應以便調試
        print(f"Raw model response: {model_response}")
        
        # 處理響應，移除<think>...</think>標籤內的內容
        import re
        clean_response = re.sub(r'<think>.*?</think>', '', model_response, flags=re.DOTALL).strip()
        print(f"Clean response: {clean_response}")
        
        # 檢查清理後的響應是否包含有效的難度等級
        valid_difficulties = ["EASY", "NON-NESTED", "NESTED"]
        
        # 首先檢查完全匹配
        if clean_response in valid_difficulties:
            return clean_response
        
        # 逐行檢查，尋找單獨一行的難度等級
        for line in clean_response.split('\n'):
            line = line.strip()
            if line in valid_difficulties:
                return line
                
        # 如果仍然找不到，檢查難度等級是否作為文本的一部分
        for difficulty in valid_difficulties:
            if difficulty in clean_response:
                return difficulty
        
        # 如果上述方法都失敗，使用基於SQL語法的規則分類
        print(f"Warning: Unclear classification response: '{clean_response}'")
        question_upper = question.upper()
        
        # 檢測子查詢和集合操作
        has_subquery = "(" in question_upper and "SELECT" in question_upper
        has_set_operations = any(op in question_upper for op in ["UNION", "INTERSECT", "EXCEPT", "MINUS"])
        
        if has_subquery or has_set_operations:
            return "NESTED"
        
        # 檢測JOIN操作
        has_join = "JOIN" in question_upper
        
        if has_join:
            return "NON-NESTED"
            
        return "EASY"
            
    except requests.exceptions.RequestException as e:
        print(f"Error connecting to model API: {e}")
        return "ERROR: Could not connect to the model"
    except Exception as e:
        print(f"Unexpected error: {e}")
        return "ERROR: An unexpected error occurred"
    
