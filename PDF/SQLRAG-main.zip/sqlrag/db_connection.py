import pyodbc
import pandas as pd
import logging
import concurrent.futures
from concurrent.futures import TimeoutError
from dataclasses import dataclass
from typing import Optional, Dict, Any, Mapping

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class DatabaseConfig:
    """Database configuration data class"""
    server: str
    username: str
    password: str
    driver: str = "ODBC Driver 17 for SQL Server"
    database: str = None  # Actual database name to connect to (may differ from key name)

# Define database-specific configurations
DB_CONFIGS = {
    "生成式AI應用使用紀錄": DatabaseConfig(
        server="UTCYMEDCLSNR01",
        username="ALS2.0_Admin_readonly",
        password="5rdxZSE$",
        database="YM_ALMS"  # Same as the key
    ),
    "MES過帳紀錄": DatabaseConfig(
        server="10.22.65.120",  # Replace with actual server name for MES_PostingRecords
        username="dc",       # Replace with actual username for MES_PostingRecords
        password="dc",   # Replace with actual password for MES_PostingRecords
        database="acme"           # The actual database name is "acme"
    )
}

def get_connection_string(database_key: str) -> str:
    if database_key not in DB_CONFIGS:
        raise ValueError(f"No configuration found for database: {database_key}")
        
    config = DB_CONFIGS[database_key]
    actual_database = config.database or database_key  # Use specified database name or key as fallback
    
    return (
        f'DRIVER={{{config.driver}}};'
        f'SERVER={config.server};'
        f'DATABASE={actual_database};'  # Use the actual database name
        f'UID={config.username};'
        f'PWD={config.password};'
        'Trusted_Connection=no;'
        'Encrypt=yes;'
        'TrustServerCertificate=yes;'
    )

class DatabaseConnection:
    """Class to manage database connections and operations"""
    
    def __init__(self, database_key: str):
        self.database_key = database_key
        
        # Validate database is supported
        if database_key not in DB_CONFIGS:
            raise ValueError(f"Unsupported database: {database_key}. Available options: {list(DB_CONFIGS.keys())}")
            
        self.config = DB_CONFIGS[database_key]
        self.actual_database = self.config.database or database_key
        self.connection_string = get_connection_string(database_key)
        self._connection = None
        
        logger.info(f"DatabaseConnection initialized for key '{database_key}' (actual db: '{self.actual_database}')")
        
    def __del__(self):
        """Ensure connection is closed when object is deleted"""
        self.close()
    
    def connect(self):
        """Create a connection to the database"""
        try:
            if not self._connection or self._connection.closed:
                logger.info(f"Connecting to database: {self.actual_database} on server {self.config.server}")
                self._connection = pyodbc.connect(self.connection_string)
            return self._connection
        except Exception as e:
            logger.error(f"Error connecting to database {self.actual_database}: {e}")
            raise
    
    def close(self):
        """Close the database connection"""
        if self._connection:
            try:
                self._connection.close()
                self._connection = None
                logger.info(f"Connection to database {self.actual_database} closed")
            except Exception as e:
                logger.error(f"Error closing database connection: {e}")
    
    def execute_query(self, sql: str, timeout: int = 60) -> pd.DataFrame:
        """
        Execute SQL query and return results as DataFrame
        
        Args:
            sql: SQL query to execute
            timeout: Query timeout in seconds
            
        Returns:
            pandas DataFrame with query results
        """
        def _execute(conn_str, query):
            with pyodbc.connect(conn_str) as conn:
                return pd.read_sql(query, conn)
                
        # Use ThreadPoolExecutor to execute SQL query with timeout
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(_execute, self.connection_string, sql)
            try:
                return future.result(timeout=timeout)
            except TimeoutError:
                logger.error(f"SQL query execution timed out after {timeout} seconds")
                raise TimeoutError(f"Query execution timed out after {timeout} seconds")
            except Exception as e:
                logger.error(f"Error executing query: {e}")
                raise
    
    def is_sql_valid(self, sql: str, timeout: int = 60) -> bool:
        """
        Validate if SQL query is valid
        
        Args:
            sql: SQL query to validate
            timeout: Query timeout in seconds
            
        Returns:
            Boolean indicating if query is valid
        """
        if not sql:
            return False
            
        def _validate(conn_str, query):
            try:
                with pyodbc.connect(conn_str) as conn:
                    with conn.cursor() as cursor:
                        cursor.execute(query)
                        cursor.fetchone()  # Fetch at least one row to ensure query runs
                return True
            except pyodbc.Error as e:
                logger.error(f"SQL validation error: {e}")
                return False
            except Exception as e:
                logger.error(f"Unexpected error during SQL validation: {e}")
                return False
                
        # Use ThreadPoolExecutor to execute validation with timeout
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(_validate, self.connection_string, sql)
            try:
                return future.result(timeout=timeout)
            except TimeoutError:
                logger.error(f"SQL validation timed out after {timeout} seconds")
                return False
            except Exception as e:
                logger.error(f"Error during SQL validation: {e}")
                return False

def create_connection(database_key: str) -> DatabaseConnection:
    """
    Factory function to create a database connection
    
    Args:
        database_key: The key name of the database configuration to use
        
    Returns:
        DatabaseConnection object
    """
    return DatabaseConnection(database_key)