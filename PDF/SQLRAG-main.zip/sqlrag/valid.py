import requests

def generate_relevance_check(question):
    """檢查問題是否與資料庫相關"""
    relevance_prompt = (
        f"請判斷以下問題是否與資料庫查詢相關：\n"
        f"問題：'{question}'\n"
        f"只回答 'YES' 或 'NO'。"
    )
    
    # 調用Ollama模型進行相關性檢查
    response = call_llm_for_relevance(relevance_prompt)
    
    # 簡單的返回值處理
    if "YES" in response.upper():
        return "YES"
    elif "NO" in response.upper():
        return "NO"
    else:
        print(f"Unclear relevance response: {response}")
        return "NO"
    
    
def call_llm_for_relevance(prompt, model="DeepSeek-R1-Distill-Qwen-32B"):
    """
    使用vLLM進行LLM調用，專門用於相關性檢查
    
    Args:
        prompt: 要發送給LLM的提示
        model: vLLM中使用的模型名稱
        
    Returns:
        模型的回應文本
    """
    try:
        # vLLM API 端點
        url = "http://10.13.18.40:55688/v1/chat/completions"
        
        # 設置請求參數
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],  # 替換 prompt 為 messages
            "temperature": 0.1,  # 低溫度以獲得更確定的回應
            "top_p": 0.9,
            "stream": False
        }
        
        # 發送請求
        response = requests.post(url, json=payload)
        
        # 檢查請求是否成功
        if response.status_code == 200:
            result = response.json()
            return result.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
        else:
            print(f"Error: Received status code {response.status_code}")
            return "ERROR"
            
    except Exception as e:
        print(f"Exception occurred: {str(e)}")
        return "ERROR"
    
def self_correction(question, df, sql):
    correction_prompt =  """#### For the given question, use the provided tables, columns, foreign keys, and primary keys to fix the given Microsoft SQL server QUERY for any issues. If there are any problems, fix them. If there are no issues, return the Microsoft SQL server SQL QUERY as is.
    #### Use the following instructions for fixing the SQL QUERY:
    1) Use the database values that are explicitly mentioned in the question.
    2) Pay attention to the columns that are used for the JOIN by using the Foreign_keys.
    3) Use DESC and DISTINCT when needed.
    4) Pay attention to the columns that are used for the GROUP BY statement.
    5) Pay attention to the columns that are used for the SELECT statement.
    6) Only change the GROUP BY clause when necessary (Avoid redundant columns in GROUP BY).
    7) Use GROUP BY on one column only.

    """