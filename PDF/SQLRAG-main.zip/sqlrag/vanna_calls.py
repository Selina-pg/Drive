import streamlit as st
from vanna.vllm import Vllm
from vanna.milvus import Milvus_VectorStore
from pymilvus import MilvusClient
from sentence_transformers import SentenceTransformer
import pandas as pd
import logging
import os
from dataclasses import dataclass
from typing import Optional, Dict, List, Any
from db_connection import create_connection

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class MilvusConfig:
    """Milvus configuration data class"""
    actual_db: str
    uri: str = "http://10.13.18.40:19530"
    db_prefix: str = "SQLRAG_"
    
MILVUS_CONFIGS = {
    "生成式AI應用使用紀錄": MilvusConfig(
        actual_db="YM_ALMS",
        uri="http://10.13.18.40:19530",
        db_prefix="SQLRAG_"
    ),
    "MES過帳紀錄": MilvusConfig(
        actual_db="MES_PostingRecords",
        uri="http://10.13.18.40:19530",
        db_prefix="SQLRAG_"
    )
}

class CustomEmbeddingFunction:
    def __init__(self, api_url="http://10.13.18.40:14514", embedding_model="Conan-embedding-v1"):
        """
        Initialize the embedding function to use an API endpoint.
        
        Args:
            api_url (str): The URL of the embedding API
            embedding_model (str): The embedding model to use
        """
        try:
            self.api_url = api_url
            self.embedding_model = embedding_model
            # Test the API connection with a simple request
            test_response = self._call_api(["Test connection"])
            if test_response is not None:
                logging.info(f"CustomEmbeddingFunction initialized with API at: {api_url}")
            else:
                raise ConnectionError("Failed to connect to embedding API")
                
        except Exception as e:
            logging.error(f"Error initializing embedding API connection: {str(e)}")
            raise
    
    def _call_api(self, texts):
        """
        Helper method to call the embedding API
        
        Args:
            texts (list): List of strings to get embeddings for
            
        Returns:
            np.ndarray: The embeddings returned by the API as a numpy array
        """
        try:
            payload = {
                "text": texts,
                "embedding_model": self.embedding_model
            }
            
            headers = {
                "Content-Type": "application/json"
            }
            
            response = requests.post(self.api_url, headers=headers, data=json.dumps(payload))
            response.raise_for_status()  # Raise an exception for HTTP errors
            
            result = response.json()
            # Converting to numpy array for compatibility
            embeddings = np.array(result.get("embeddings", []))
            return embeddings
            
        except Exception as e:
            logging.error(f"Error calling embedding API: {str(e)}")
            raise

    def __call__(self, texts):
        if isinstance(texts, str):
            texts = [texts]
        embeddings = self._call_api(texts)
        return embeddings
    
    def encode_documents(self, texts):
        if isinstance(texts, str):
            texts = [texts]
        logging.debug(f"Encoding documents: {texts[:100]}...")
        return self._call_api(texts)
    
    def encode_queries(self, texts):
        if isinstance(texts, str):
            texts = [texts]
        logging.debug(f"Encoding queries: {texts[:100]}...")
        return self._call_api(texts)

# Initialize the sentence transformer model
class CustomEmbeddingFunction:
    def __init__(self, base_path="/root/.cache/huggingface/hub/models--TencentBAC--Conan-embedding-v1"):
        try:
            # 找到 snapshots 目錄下的具體版本目錄
            snapshots_dir = os.path.join(base_path, "snapshots")
            if os.path.exists(snapshots_dir):
                # 獲取 snapshots 下的第一個目錄
                snapshot_versions = os.listdir(snapshots_dir)
                if snapshot_versions:
                    model_path = os.path.join(snapshots_dir, snapshot_versions[0])
                    self.model = SentenceTransformer(model_path)
                    logging.info(f"CustomEmbeddingFunction initialized with local model from: {model_path}")
                else:
                    raise ValueError(f"No model snapshots found in {snapshots_dir}")
            else:
                raise ValueError(f"Snapshots directory not found at {snapshots_dir}")
                
        except Exception as e:
            logging.error(f"Error loading model: {str(e)}")
            raise

    def __call__(self, texts):
        if isinstance(texts, str):
            texts = [texts]
        embeddings = self.model.encode(texts, normalize_embeddings=True)
        return embeddings
    
    def encode_documents(self, texts):
        if isinstance(texts, str):
            texts = [texts]
        logging.debug(f"Encoding documents: {texts[:100]}...")
        return self.model.encode(texts, normalize_embeddings=True)
    
    def encode_queries(self, texts):
        if isinstance(texts, str):
            texts = [texts]
        logging.debug(f"Encoding queries: {texts[:100]}...")
        return self.model.encode(texts, normalize_embeddings=True)

class MyVanna(Milvus_VectorStore, Vllm):
    """Custom Vanna class integrating Milvus and Ollama functionality"""
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        Milvus_VectorStore.__init__(self, config=config)
        Vllm.__init__(self, config=config)
        self._db_connection = None
        self._current_db = None

    def connect_to_database(self, database: str):
        """Connect to the specified database"""
        if self._current_db != database or self._db_connection is None:
            logger.info(f"Creating new connection to database: {database}")
            if self._db_connection:
                self._db_connection.close()
            self._db_connection = create_connection(database)
            self._current_db = database
        return self._db_connection
    
    def generate_sql(self, question: str, allow_llm_to_see_data: bool = True, difficulty: str = None, database: str = None) -> str:
        # If database is provided and different from current, connect to it first
        if database and self._current_db != database:
            self.connect_to_database(database)
        
        # Call the parent class's generate_sql method with the appropriate parameters
        return super().generate_sql(question=question, allow_llm_to_see_data=allow_llm_to_see_data, difficulty=difficulty)

    def execute_sql(self, sql: str, timeout: int = 60) -> pd.DataFrame:
        self.connect_to_database(get_current_database())
        return self._db_connection.execute_query(sql, timeout)

    def validate_sql(self, sql: str, timeout: int = 60) -> bool:
        self.connect_to_database(get_current_database())
        return self._db_connection.is_sql_valid(sql, timeout)

# Helper function to fetch the current database from session state
def get_current_database() -> str:
    return st.session_state.get('database_selector','生成式AI應用使用紀錄')

# Centralized setup function for MyVanna instance
@st.cache_resource(ttl=3600)
def setup_vanna(database_name: str) -> MyVanna:
    try:
        # Get the Milvus configuration for the database
        milvus_config = MILVUS_CONFIGS.get(database_name)
        if not milvus_config:
            # Fallback to default config if not found
            milvus_config = MilvusConfig(actual_db=database_name)
            logger.warning(f"No specific Milvus config found for {database_name}, using default")

        milvus_client = MilvusClient(
            uri=milvus_config.uri,
            db_name=f"{milvus_config.db_prefix}{milvus_config.actual_db}"
        )
        
        vn = MyVanna(config={
            'model': 'DeepSeek-R1-Distill-Qwen-32B',
            'milvus_client': milvus_client,
            'embedding_function': CustomEmbeddingFunction(),
            'n_results': 2,
        })
        vn.connect_to_database(database_name)
        logger.info(f"Vanna instance initialized with database: {database_name}, Milvus DB: {milvus_config.actual_db}")
        return vn
    except Exception as e:
        logger.error(f"Error in setup_vanna: {e}")
        raise

# Centralized function to get Vanna instance
def get_vanna_instance() -> MyVanna:
    current_db = get_current_database()
    return setup_vanna(current_db)

# Cached functions with reduced redundancy
@st.cache_data(show_spinner="Generating sample questions ...")
def generate_questions_cached() -> List[str]:
    vn = get_vanna_instance()
    return vn.generate_questions()

@st.cache_data(show_spinner="Generating SQL query ...")
def generate_sql_cached(question: str, difficulty: str, database: str = None) -> str:
    vn = get_vanna_instance()
    # If database is not provided, use the current selected database
    if database is None:
        database = get_current_database()
    return vn.generate_sql(question=question, allow_llm_to_see_data=True, difficulty=difficulty, database=database)

@st.cache_data(show_spinner="Validating SQL query ...")
def is_sql_valid_cached(sql: str) -> bool:
    vn = get_vanna_instance()
    return vn.validate_sql(sql)

@st.cache_data(show_spinner="Running SQL query ...")
def run_sql_cached(sql: str) -> pd.DataFrame:
    vn = get_vanna_instance()
    return vn.execute_sql(sql)

@st.cache_data(show_spinner="Generating summary ...")
def generate_summary_cached(question: str, df: pd.DataFrame) -> str:
    vn = get_vanna_instance()
    return vn.generate_summary(question=question, df=df)

@st.cache_data(show_spinner="Training model ...")
def train_model_cached(question: str, sql: str) -> bool:
    vn = get_vanna_instance()
    return vn.train(question=question, sql=sql)

@st.cache_data(show_spinner="Checking if chart generation is needed ...")
def should_generate_chart_cached(df: pd.DataFrame) -> bool:
    vn = get_vanna_instance()
    return vn.should_generate_chart(df=df)

@st.cache_data(show_spinner="Generating Plotly code ...")
def generate_plotly_code_cached(question: str, sql: str, df: pd.DataFrame) -> str:
    vn = get_vanna_instance()
    return vn.generate_plotly_code(question=question, sql=sql, df=df)

@st.cache_data(show_spinner="Generating Plotly chart ...")
def generate_plot_cached(code: str, df: pd.DataFrame):
    vn = get_vanna_instance()
    return vn.get_plotly_figure(plotly_code=code, df=df)